
# Onboarding Form

A React-based Onboarding form that collects employee information, access requirements, and equipment needs. The form dynamically adjusts based on user inputs and generates a JSON object that can be downloaded.

